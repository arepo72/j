import P1.*;
class DemoP1
{
public static void main(String []args)
{
int res;
fact f=new fact();
res=f.findfact(6);
System.out.println("The result is"+res);
}
}

