package P1;
import java.lang.*;
import java.util.*;
public class fact
{
public int n;
public int f=1;
public int findfact(int n)
{
for(int i=1;i<=n;i++){
f=f*i;
}
return f;
}
}


